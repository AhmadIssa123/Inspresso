import unittest

from inspresso.analyzer import GOOD, TOO_COARSE, TOO_FINE, analyze_shot
from inspresso.config import InspressoConfig
from inspresso.models import ShotMeasurement


class AnalyzerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = InspressoConfig()

    def test_good_shot(self) -> None:
        result = analyze_shot(ShotMeasurement(36.0, 30.0), self.config)
        self.assertEqual(result.classification, GOOD)

    def test_fast_high_yield_shot(self) -> None:
        result = analyze_shot(ShotMeasurement(43.0, 20.0), self.config)
        self.assertEqual(result.classification, TOO_COARSE)

    def test_slow_low_yield_shot(self) -> None:
        result = analyze_shot(ShotMeasurement(28.0, 40.0), self.config)
        self.assertEqual(result.classification, TOO_FINE)


if __name__ == "__main__":
    unittest.main()
